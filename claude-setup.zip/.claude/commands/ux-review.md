Fetch and read BOTH of these URLs in full before doing anything else. The spec contains every rule you will check against. The UX context contains the personas and UX laws.

1. Design system spec:
   https://anthu211.github.io/design-system-2.0/spec.md

2. UX context:
   https://anthu211.github.io/design-system-2.0/ux-context.md

---

Review this screen or component against the Prevalent AI design system spec and UX laws:

$ARGUMENTS

---

Return your review as a structured pass/fail checklist using this exact format. Mark each item `✅ PASS` or `❌ FAIL`. For every FAIL, include one sentence explaining what is wrong and the exact fix (colour value, CSS property, or pattern name from the spec).

---

## UX Review

### Shell & Structure
- [ ] Uses mandatory shell: topbar + left nav + content sub-header + content body
- [ ] Topbar background is `#131313`
- [ ] Left nav is white (`#ffffff`) in light theme
- [ ] Content sub-header is sticky with page title + breadcrumb

### Tokens & Styling
- [ ] Accent colour is `#6360D8` — no substitutes
- [ ] Filter / Active Filters CTA uses `#504bb8` — not `#6360D8`
- [ ] ALL buttons use `border-radius: 44px` (pill) — no `6px`, `8px`, or `rounded-md`
- [ ] Font is Inter — Google Fonts link present
- [ ] Generated with `<html class="theme-light">` (light mode default)
- [ ] Spacing uses 4px base unit — no arbitrary pixel values

### Component Patterns
- [ ] Status (severity/state) is visible in default table columns — not tooltip-only
- [ ] List data uses a table layout — not cards
- [ ] KPI cards ≤ 5 in a row
- [ ] Table columns ≤ 7 visible by default (extras opt-in via Add Column)
- [ ] Destructive actions have a confirmation modal naming the item and stating the consequence
- [ ] Error states include a text message below the field — not just a red border
- [ ] Buttons have clear primary / secondary / tertiary visual hierarchy

### UX Laws
- [ ] **Hick's Law** — max 1 primary CTA per screen section; navigation collapsed by default; dropdowns with 10+ options have a search field
- [ ] **Fitts's Law** — row actions visible on hover (not right-click); primary CTAs min 32px height; filter/export controls in table sub-header (not floating)
- [ ] **Miller's Law** — KPI row ≤ 5 cards; nav sections ≤ 7 items; table columns ≤ 7 default
- [ ] **Jakob's Law** — checkboxes in leftmost table column; Cancel left of Confirm in modal footers; pagination bottom-right; search triggers on type

### Persona Fit
- [ ] Layout matches the intended persona's primary goals (state which persona)
- [ ] No known frustration triggers for that persona are present in the design

---

After the checklist, add a **Summary** section:
- Total PASS count
- Total FAIL count
- One sentence on the most critical issue to fix first (if any FAILs)
