Fetch and read BOTH of these URLs in full before doing anything else. Do not skip this step — every token, component pattern, shell rule, persona, and UX law you need is in these files.

1. Design system spec (tokens, components, shell, layout rules, React patterns):
   https://anthu211.github.io/design-system-2.0/spec.md

2. UX context (personas, UX laws, product principles):
   https://anthu211.github.io/design-system-2.0/ux-context.md

---

Generate a complete UI component or screen for: $ARGUMENTS

Parse the arguments as follows:
- **Word 1** — component or screen name (e.g. `AlertsTable`, `RiskDashboard`, `IntegrationSettings`)
- **Word 2** — persona: `analyst` | `ciso` | `it-admin`
- **Word 3** (optional) — output format: `react` for TSX, omit for HTML

---

## If output is HTML (no third argument)

Return a complete, self-contained HTML file. Requirements:

- Include `<!DOCTYPE html>`, `<html lang="en" class="theme-light">`, full `<head>` with Google Fonts Inter link
- Use the **mandatory shell structure** from the spec: topbar → left nav → content sub-header → content body
- Save or display the file named `[component-name].html`
- All styles must be inline or in a `<style>` block — no external CSS files
- Include all JavaScript in a `<script>` block at the bottom

---

## If output is React (third argument is `react`)

Return TypeScript + Tailwind CSS + Radix UI component files. Requirements:

- Read the **React / Developer Reference** section at the bottom of spec.md — use those exact component patterns
- Output individual `.tsx` files, one component per file, placed in `src/components/ui/`
- Use the Tailwind config token names: `bg-accent`, `text-accent`, `rounded-pill`, `bg-topbar`, etc.
- Use Radix UI primitives for: Dialog, Select, Checkbox, Tabs, DropdownMenu
- Shell layout uses the `Shell` component from `src/components/shell/Shell.tsx`
- No inline styles except the Navigator gradient text

---

## Persona rules (apply to both HTML and React)

**analyst**
- Lead with a DataTable, not cards
- SeverityBadge visible in default columns — never hidden in a tooltip
- Row-level actions appear on hover (view, edit, delete)
- Sort, filter, and export controls in the content sub-header — not floating
- Avoid modal-heavy flows — keep context visible while acting

**ciso**
- Lead with KPICard row (3–5 cards max — Miller's Law)
- Trend direction must show direction AND whether it's good or bad (colour + arrow)
- Use donut or line charts for trends, not tables
- Max 4–5 metrics on a summary screen — remove everything else
- Minimal jargon: "Total Risk Score" not "CVSS aggregate"
- One dominant CTA — the CISO should know exactly what to do

**it-admin**
- Form inputs must have clear validation messages below the field (not just red borders)
- Integration status must show: source name, last sync time, error reason if failed
- Settings grouped into labelled sections — never one long flat form
- Destructive actions (delete, disconnect) require a Dialog with item name + consequence
- Empty states must explain why data is missing and what to do next

---

## Non-negotiable rules (apply always, without exception)

- Topbar is always `#131313` — never theme-switched
- Accent is always `#6360D8`. Filter / Active Filters CTA always uses `#504bb8`
- ALL buttons use `border-radius: 44px` (pill). Never `rounded-md` or `6px` on a button
- Font is always Inter
- Light theme is default — `<html class="theme-light">` for HTML, `font-sans` via Tailwind config for React
- Status is never hidden in a tooltip only — always visible in default table column
- Tables before cards for list data
- Destructive actions always need a confirmation modal: item name + consequence + red confirm button
- Cancel is always LEFT of Confirm/Save in modal footers (Jakob's Law)
- Spacing on 4px base unit: 4, 8, 12, 16, 20, 24, 32, 48px — no arbitrary values
- KPI rows: 3–5 cards maximum (Miller's Law)
- Table columns: 5–7 visible by default — extras opt-in via Add Column
