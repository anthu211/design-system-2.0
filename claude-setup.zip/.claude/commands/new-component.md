Fetch and read ALL of these URLs in full before doing anything else. Do not skip this step.

1. Design tokens + rules: https://anthu211.github.io/design-system-2.0/spec.md
2. UI component patterns: https://anthu211.github.io/design-system-2.0/components.md
3. UX context (personas + UX laws): https://anthu211.github.io/design-system-2.0/ux-context.md

If adding a chart, also fetch: https://anthu211.github.io/design-system-2.0/charts.md

---

The user's request is: $ARGUMENTS

Your job is to add a new component to an existing HTML page in the current working directory.

## Step 1 — Parse the request

Read the request and determine:
- **What component** to add (e.g. "filter bar", "KPI cards row", "confirmation modal", "empty state")
- **Which file** to add it to — if the user names a file, use it. If not, look for `.html` files in the current directory and ask the user which one, or infer from context.
- **Where** in the page it should go (e.g. in the content body, in the sub-header, as a modal overlay)

## Step 2 — Read the target file

Read the target HTML file so you understand the existing structure, styles, and JavaScript before making any changes.

## Step 3 — Add the component

Add the component to the file by editing it in place. Do not rewrite the whole file — only add what's needed:
- New HTML markup in the right place in the DOM
- New CSS rules added to the existing `<style>` block
- New JavaScript functions added to the existing `<script>` block

### Component rules (always apply)

- Match the existing page's design tokens exactly — use the same CSS variables already in the file
- ALL buttons use `border-radius: 44px` (pill). Never `6px`
- Accent is `#6360D8`. Filter / Active Filters CTA uses `#504bb8`
- Spacing on 4px base unit only
- New modals follow the pattern: overlay → modal card → header → body → footer (Cancel LEFT, Confirm RIGHT)
- New table columns don't exceed 7 visible by default
- Status / severity badges are always visible, never tooltip-only
- Destructive confirm buttons are always red (`#d93025` or equivalent danger token)
- Inter font is already loaded — do not add another font link

### Persona-aware additions

If the existing page is clearly for a specific persona, match their needs:
- **ciso** — new components should be summary-focused; limit new metrics to what's truly needed; never add more than 5 KPI cards total
- **grc** — new components should support evidence collection, control status, or export; group by framework domain
- **security-architect** — new components should expose technical detail; never oversimplify labels or hide configuration values
- **security-engineer** — new components should add density, filtering, or bulk actions; form additions need inline validation messages
- **soc-analyst** — new components should keep the alert queue visible and unobstructed; avoid modal-heavy additions during triage

## Step 4 — Confirm the change

After editing the file, tell the user:
- What was added and where
- Any design decisions made (e.g. "Added the modal as a hidden overlay — triggered by the Delete button in each row")
- If anything in the existing file was adjusted to accommodate the new component
