Fetch and read BOTH of these URLs in full before doing anything else. The UX context has the full persona definitions. The spec has the component rules that translate persona needs into UI decisions.

1. UX context (personas, UX laws, product principles):
   https://anthu211.github.io/design-system-2.0/ux-context.md

2. Design system spec (component and layout rules):
   https://anthu211.github.io/design-system-2.0/spec.md

---

Analyse this feature, screen, or design decision against the Prevalent AI user personas:

$ARGUMENTS

---

Return your analysis in this exact format:

---

## Persona Check

### Primary Persona
State which persona this primarily serves — **analyst**, **ciso**, or **it-admin** — and explain why in one sentence. If it genuinely serves multiple personas equally, name both.

### Goals This Feature Serves
List the specific goals from the persona's section of ux-context.md that this feature directly addresses. Quote the goal text exactly, then explain how the feature serves it.

### Frustrations This Feature Risks Triggering
List any of the persona's known frustrations (from ux-context.md) that the current description could trigger. For each, explain the specific design choice that would cause it. If none apply, say so explicitly — do not leave this blank.

### UI Implications Check
Work through each UI implication listed under this persona in ux-context.md. For each implication, state:
- **Respected** — the feature description aligns with it, or
- **Violated** — the feature description conflicts with it (explain the conflict)
- **Unknown** — not enough detail to assess (state what information is missing)

### Adjustments (if issues found)
If any frustrations or violations were identified, provide 1–3 specific, actionable changes. Each adjustment must:
- Name the exact change to make
- Reference the spec rule or UX law it comes from
- Be concrete enough that a developer can implement it immediately

If no issues were found, say "No adjustments needed — this feature aligns well with [persona] goals."

### Secondary Persona Impact
If this feature is likely to be used by a second persona (e.g. a CISO viewing an analyst-built dashboard), briefly note:
- Which persona
- Whether the feature serves or harms them
- One adjustment if it harms them

---
