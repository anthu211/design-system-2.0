Fetch and read BOTH of these URLs in full before doing anything else. Do not skip this step.

1. Design system spec (tokens, components, shell, layout rules):
   https://anthu211.github.io/design-system-2.0/spec.md

2. UX context (personas, UX laws, product principles):
   https://anthu211.github.io/design-system-2.0/ux-context.md

---

The user's requirement is: $ARGUMENTS

Your job is to generate a complete, self-contained HTML page for this requirement and save it as a file in the current working directory.

## Step 1 — Parse the requirement

Read the requirement and determine:
- **What screen or feature** is being built (e.g. "alerts dashboard", "integration settings", "risk findings detail")
- **Which persona** it primarily serves — infer from the content if not stated:
  - Dense tables, severity filtering, bulk actions → `analyst`
  - KPI overview, trends, executive summary → `ciso`
  - Settings, integrations, form configuration → `it-admin`
- **File name** — derive a kebab-case filename from the requirement (e.g. `alerts-dashboard.html`, `integration-settings.html`, `risk-findings.html`)

## Step 2 — Generate the page

Build a complete, self-contained HTML file using the spec and persona rules below.

### Shell structure (mandatory — no exceptions)
Use the exact shell from the spec:
- Topbar (`#131313`, always)
- Left nav (collapsed sections by default — Hick's Law)
- Content sub-header (page title + primary actions)
- Content body (the main content)

### HTML requirements
- `<!DOCTYPE html>` + `<html lang="en" class="theme-light">`
- Full `<head>` with Google Fonts Inter: `<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">`
- All styles in a `<style>` block — no external CSS files
- All JavaScript in a `<script>` block at the bottom
- Realistic placeholder data that matches the security domain (vulnerabilities, risk scores, vendor names, CVE IDs, etc.)

### Persona rules

**analyst** (default for table/list/findings screens)
- Lead with a DataTable, not cards
- SeverityBadge visible in default columns — never hidden in tooltip
- Row-level actions on hover (view, edit, delete)
- Sort, filter, and export in the content sub-header
- Status always visible in default view

**ciso** (default for dashboard/overview/summary screens)
- Lead with KPICard row (3–5 cards — Miller's Law)
- Trend direction shows direction AND whether it's good/bad (colour + arrow)
- Use donut or line charts for trends
- Max 4–5 metrics — remove everything else
- One dominant CTA

**it-admin** (default for settings/integration/configuration screens)
- Form inputs have validation messages below the field (not just red borders)
- Integration status shows: source name, last sync time, error reason if failed
- Settings grouped into labelled sections
- Destructive actions (delete, disconnect) require a Dialog: item name + consequence + red confirm button

### Non-negotiable rules (always apply)
- Topbar is always `#131313`
- Accent is always `#6360D8`. Filter / Active Filters CTA always uses `#504bb8`
- ALL buttons use `border-radius: 44px` (pill). Never `rounded-md` or `6px` on a button
- Font is always Inter
- Status is never hidden in tooltip only — always visible in default table column
- Tables before cards for list data
- Destructive actions always need a confirmation modal: item name + consequence + red confirm button
- Cancel is always LEFT of Confirm in modal footers
- Spacing on 4px base unit: 4, 8, 12, 16, 20, 24, 32, 48px
- KPI rows: 3–5 cards max (Miller's Law)
- Table columns: 5–7 visible by default
- KPI card: `border-radius: 8px; padding: 16px 20px`
- Content card: `border-radius: 12px`

## Step 3 — Save the file

Write the generated HTML to a file named `[derived-filename].html` in the current working directory using your file write tool.

After saving, tell the user:
- The filename that was created
- Which persona was applied and why
- Any key design decisions made (e.g. "Led with a table because analysts need density")
