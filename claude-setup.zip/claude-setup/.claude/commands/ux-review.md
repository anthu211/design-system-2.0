Load design system context:
Fetch: https://anthu211.github.io/design-system-2.0/ds/context.json
Read the rules array fully. Fetch rules.json.
Also fetch: tokens/colors.json, tokens/spacing.json, tokens/typography.json

The file or description to review: $ARGUMENTS

If $ARGUMENTS is empty, ask the user: "Which file or folder should I review?"
Wait for the answer. Then read the specified files in full.

REVIEW CHECKLIST — check every item:
[ ] 1. Colors — any hardcoded hex values? Flag each one with file:line
[ ] 2. Spacing — any values not on the 4pt grid (4,8,12,16,20,24,32,48px)? Flag each one
[ ] 3. Typography — any font sizes outside the defined scale (10,11,12,13,14px)?
[ ] 4. States — missing hover, active, focus, or disabled on any interactive element?
[ ] 5. Shell — is a valid shell from patterns/shells.json being used, or was layout invented?
[ ] 6. Navigation — sub-header has two lines (title + breadcrumb)? Nav label is workspace name not "Prevalent AI"?
[ ] 7. Tables — column order correct? Row actions CSS-hidden? Status in own cell? Pagination present?
[ ] 8. Components — KPI cards ≤5, no icons/borders? Destructive actions have modal? No uninvited tabs?
[ ] 9. Rules — does anything violate the rules array from context.json?

Output format:
PASS: [items with no issues]
FIX: [item] — [file:line] — [what to change]
SUGGESTION: [optional improvement, not a violation]

Summary: X PASS · X FIX · most critical fix first
